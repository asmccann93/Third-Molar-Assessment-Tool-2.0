/* Root service worker — deliberately a kill switch, not a cache.
 *
 * The third molar tool used to live at the site root, so anyone who has visited
 * before still has a service worker registered at scope "/". That old worker
 * controls EVERY path on this domain, including /sedation/ and /third-molar/.
 * Left in place it would keep answering navigations from its own cache, and its
 * offline fallback resolves to the root index — so a sedation URL could serve
 * the third molar app when the connection drops.
 *
 * Browsers re-check this file automatically, so serving this version replaces
 * the old worker, clears its caches, unregisters it, and reloads any open tab.
 * Each tool then registers its own worker, scoped to its own folder.
 *
 * Keep this file here permanently. Removing it would 404 and leave the old
 * worker in place on any browser that has not yet updated.
 */

self.addEventListener("install", function () {
  self.skipWaiting();
});

self.addEventListener("activate", function (e) {
  e.waitUntil(
    caches.keys()
      .then(function (keys) {
        return Promise.all(keys.map(function (k) { return caches.delete(k); }));
      })
      .then(function () { return self.registration.unregister(); })
      .then(function () { return self.clients.matchAll({ type: "window" }); })
      .then(function (clients) {
        clients.forEach(function (c) {
          /* Reload so the page is served from the network, uncontrolled */
          if ("navigate" in c) c.navigate(c.url);
        });
      })
      .catch(function () { /* nothing useful to do if cleanup fails */ })
  );
});

/* Pass everything straight through while this worker is still alive */
self.addEventListener("fetch", function () {});
